interface Aluno {
    nome: string,
    idade: number
}


import { soma } from './soma'
import { sub } from './sub'

console.log(soma(10, 20));
console.log(sub(10,20));
