export function soma(x : number, y : number) : number{
    return x+y;
}
