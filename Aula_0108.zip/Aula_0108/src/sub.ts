export function sub(x : number, y : number) : number{
    return x-y;
}

